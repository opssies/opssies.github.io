#!/usr/bin/perl
use strict;
use warnings;
use FindBin;
use lib "$FindBin::Bin";  # Pour trouver le module dans le même répertoire
use OpssiesD1JsonSchemaValidator;
use Getopt::Long;

# Paramètres en ligne de commande
my $schema_file;
my $instance_file;
my $help;

GetOptions(
    "schema=s"   => \$schema_file,
    "instance=s" => \$instance_file,
    "help"       => \$help
) or die "Usage incorrect\n";

if ($help) {
    print "Usage: $0 --schema fichier_schema.json --instance fichier_instance.json\n";
    exit;
}

die "Fichier de schéma requis\n" unless $schema_file;
die "Fichier d'instance requis\n" unless $instance_file;

# Vérification de l'existence des fichiers
die "Le fichier de schéma n'existe pas: $schema_file\n" unless -f $schema_file;
die "Le fichier d'instance n'existe pas: $instance_file\n" unless -f $instance_file;

# Création du validateur
my $validator = OpssiesD1JsonSchemaValidator->new();

# Chargement du schéma
unless ($validator->load_schema($schema_file)) {
    die "Erreur lors du chargement du schéma\n";
}

# Validation de l'instance
my ($is_valid, $errors) = $validator->validate_instance($instance_file);

if ($is_valid) {
    print "✓ L'instance json est valide selon le schéma d'interopérabilité OPSSIES V2 v0.13 décliné pour le volet D1 Industriel, dans sa structure (hors volet sémantique) \n";
} else {
    print "✗ L'instance json n'est pas valide\n";
    print "Détails des erreurs:\n";
    print "-" x 50 . "\n";
    foreach my $error (@$errors) {
    
    	# Retrait de la mention du module dans l'erreur retournée
        if ($error =~ /JsonSchemaValidator.pm/) {
        $error =~ s/at \/.*$//;
    }
    
        print "$error\n";
        print "-" x 50 . "\n";
              
    }
    exit 1;
}
