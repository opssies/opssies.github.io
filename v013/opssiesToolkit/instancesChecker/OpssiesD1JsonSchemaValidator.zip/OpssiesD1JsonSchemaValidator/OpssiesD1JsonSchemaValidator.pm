package OpssiesD1JsonSchemaValidator;
use strict;
use warnings;
use JSON::Schema;
use JSON;
use Try::Tiny;
use Data::Dumper;

sub new {
    my $class = shift;
    my $self = {
        errors => [],
        schema => undef,
        validator => undef
    };
    return bless $self, $class;
}

sub load_schema {
    my ($self, $schema_file) = @_;
    
    try {
        local $/;
        open my $fh, "<", $schema_file or die "Impossible d'ouvrir le schéma $schema_file: $!";
        my $schema_content = <$fh>;
        close $fh;
        
        $self->{schema} = decode_json($schema_content);
        $self->{validator} = JSON::Schema->new($self->{schema});
        return 1;
    } catch {
        push @{$self->{errors}}, "Erreur lors du chargement du schéma: $_";
        return 0;
    };
}

sub validate_instance {
    my ($self, $instance_file) = @_;
    
    return (0, ["Le schéma n'a pas été chargé"]) unless $self->{validator};
    
    try {
        local $/;
        open my $fh, "<", $instance_file or die "Impossible d'ouvrir l'instance $instance_file: $!";
        my $instance_content = <$fh>;
        close $fh;
        
        my $instance = decode_json($instance_content);
        my @validation_errors;
        
        # Validation principale
        my $result = $self->{validator}->validate($instance);
        
        if ($result) {
            return (1, ["L'instance est valide"]);
        } else {
            my @detailed_errors = $self->_analyze_errors($result->errors);
            return (0, \@detailed_errors);
        }
    } catch {
        return (0, ["Erreur lors de la validation: $_"]);
    };
}

sub _analyze_errors {
    my ($self, $errors) = @_;
    my @detailed_errors;
    
    foreach my $error (@$errors) {
        my $path = $error->path || 'racine';
        my $message = $error->message;
        
        # Amélioration des messages d'erreur
        my $detailed_message = $self->_enhance_error_message($error);
        
        push @detailed_errors, {
            path => $path,
            message => $detailed_message,
            found => $error->found,
            expected => $error->expected
        };
    }
    
    return map {
        sprintf(
            "Erreur à '%s': %s\n  Trouvé: %s\n  Attendu: %s",
            $_->{path},
            $_->{message},
            defined $_->{found} ? $_->{found} : 'non défini',
            defined $_->{expected} ? $_->{expected} : 'conforme au schéma'
        )
    } @detailed_errors;
}

sub _enhance_error_message {
    my ($self, $error) = @_;
    
    my $base_message = $error->message;
    my $enhanced_message = $base_message;
    
    # Enrichissement des messages selon le type d'erreur
    if ($base_message =~ /type/) {
        $enhanced_message .= "\nConseil: Vérifiez que le type de données correspond à celui défini dans le schéma";
    }
    elsif ($base_message =~ /required/) {
        $enhanced_message .= "\nConseil: Ajoutez la propriété manquante avec une valeur appropriée";
    }
    elsif ($base_message =~ /pattern/) {
        $enhanced_message .= "\nConseil: La valeur doit correspondre au format spécifié dans le schéma";
    }
    elsif ($base_message =~ /enum/) {
        $enhanced_message .= "\nConseil: La valeur doit être l'une de celles autorisées dans l'énumération";
    }
    
    return $enhanced_message;
}

1;
