package Opssies;

use 5.038002;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Opssies ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	CaRED1SampleGenerate
);

our $VERSION = '0.01';


# Preloaded methods go here.

sub CaRED1SampleGenerate { 

my $instanceQuantity = @_;
my $instance = 1;

my $siren = (int(rand(100000000)) + 899999999) . (int(rand(10000)) + 79999);#"433428018" (9 + 5)
my $raisonSocialePrestataire = "Prestataire en cybersécurité " . $siren; #2
my $raisonSocialePrestataireAbregee = "Prestataire " . $siren; #1

my $finess = (int(rand(88)) + 10) . (int(rand(1000000)) + 7999999); #474454647 (2 + 7)
my $raisonSocialeESIndex = 1;
my $raisonSocialeES = "Centre hospitalier " . $finess; #2
my $raisonSocialeESAbregee = "CH " . $finess; #1

my $date = "202406" . int(rand(30)+10) . "-" . int(rand(23)+10) . "0101";
my $level = int(rand(3));

my @functionalContext = ("Questionnaires -Enquetes", "Système décisionnel", "Messagerie Sécurisée PS", "Portail Extranet PS", "Télémédecine", "Plate-forme institutionnelle", "Plate-forme associative");
my @functionalContextCode = ("68", "69", "70", "71", "72", "73", "74");

my $indexFunctionalContext = int(rand @functionalContext);
my $functionalContextItem = $functionalContext[$indexFunctionalContext];
my $functionalContextItemCode = $functionalContextCode[$indexFunctionalContext];
my $userCount = int(rand(350));

my $filename = "opssies-cared1-instance_sample";
my $extension = "json";

my $instancefile;
my $str;

while($instance <= $instanceQuantity) {

	# Opens file handler
	open($instancefile, '>', "$filename-$instance.$extension") or die $!;

	# Generates sample data
	$siren = (int(rand(100000000)) + 899999999) . (int(rand(10000)) + 79999);#"433428018" (9 + 5)
	$raisonSocialePrestataire = "Prestataire en cybersécurité " . $siren; #2
	$raisonSocialePrestataireAbregee = "Prestataire " . $siren; #1

	$finess = (int(rand(88)) + 10) . (int(rand(1000000)) + 7999999); #474454647 (2 + 7)
	$raisonSocialeESIndex = 1;
	$raisonSocialeES = "Centre hospitalier " . $finess; #2
	$raisonSocialeESAbregee = "CH " . $finess; #1

	$date = "20240115-141742";
	$level = int(rand(3));

	@functionalContext = ("Questionnaires -Enquetes", "Système décisionnel", "Messagerie Sécurisée PS", "Portail Extranet PS", "Télémédecine", "Plate-forme institutionnelle", "Plate-forme associative");
	@functionalContextCode = ("68", "69", "70", "71", "72", "73", "74");

	$indexFunctionalContext = int(rand @functionalContext);
	$functionalContextItem = $functionalContext[$indexFunctionalContext];
	$functionalContextItemCode = $functionalContextCode[$indexFunctionalContext];
	$userCount = int(rand(350));

	# Pushes predefined json (1 event) instance with sample data
$str = <<MYSAMPLE;
{
    "events": {
        "stakeholders": [
            {
                "stakeholderId": {
                    "stakeholderIdType": 4,
                    "__text": "$siren"
                },
                "stakeholderNameTypes": [
                    {
                        "stakeholderNameType": 1,
                        "__text": "$raisonSocialePrestataireAbregee"
                    },
                    {
                        "stakeholderNameType": 2,
                        "__text": "$raisonSocialePrestataire"
                    }
                ],
                "stakeholderType": 3,
                "stakeholderRoleType": 2
            },
            {
                "stakeholderId": {
                    "stakeholderIdType": 5,
                    "__text": "187512751"
                },
                "stakeholderNameTypes": [
                    {
                        "stakeholderNameType": 1,
                        "__text": "ANS"
                    },
                    {
                        "stakeholderNameType": 2,
                        "__text": "Agence du Numérique en Santé"
                    }
                ],
                "stakeholderType": 2,
                "stakeholderRoleType": 3
            },
            {
                "stakeholderId": {
                    "stakeholderIdType": 3,
                    "__text": "750712184"
                },
                "stakeholderNameTypes": [
                    {
                        "stakeholderNameType": 1,
                        "__text": "$raisonSocialeESAbregee"
                    },
                    {
                        "stakeholderNameType": 2,
                        "__text": "$raisonSocialeES"
                    }
                ],
                "stakeholderType": 2,
                "stakeholderRoleType": 1
            }
        ],
        "event": [
            {
                "stakeholders": [
                    {
                        "stakeholderId": [
                            {
                                "stakeholderIdType": 2,
                                "__text": "930100037"
                            }
                        ],
                        "stakeholderNameTypes": [
                            {
                                "stakeholderNameType": 1,
                                "__text": "$raisonSocialeESAbregee"
                            },
                            {
                                "stakeholderNameType": 2,
                                "__text": "$raisonSocialeES"
                            }
                        ],
                        "stakeholderType": 1,
                        "stakeholderRoleType": 4
                    }
                ],
                "functionalContexts": [
                    {
                        "functionalContextCategory": 71,
                        "__text": "portail extranet ps"
                    },
                    {
                        "functionalContextCategory": 73,
                        "__text": "site institutionnel"
                    }
                ],
                "technicalContexts": [
                    {
                        "technicalContextCategory": 13,
                        "__text": "vlan4094"
                    },
                    {
                        "technicalContextCategory": 13,
                        "__text": "vlan4095"
                    }
                ],
                "dates": [
                    {
                        "dateType": 7,
                        "__text": "$date"
                    }
                ],
                "scopes": [
                    {
                        "functionalContexts": [
                            {
                                "functionalContextCategory": $functionalContextItemCode,
                                "__text": "$functionalContextItem",
                                "isPersonalData": false,
                                "isPersonalHealthcareData": false,
                                "userCount": $userCount 
                            }
                        ],
                        "technicalContexts": [
                            {
                                "technicalContextCategory": 13,
                                "__text": "vlanX",
                                "isDynamic": false,
                                "isAuthenticatable": false,
                                "isOnCloud": false
                            }
                        ],
                        "autonomousSystemNumbers": [
                            "AS3215",
                            "AS15557",
                            "AS5410"
                        ],
                        "domains": [
                            "corp1.example-ght.fr",
                            "corp2.example-ght.fr",
                            "corp3.example-ght.fr"
                        ],
                        "subnetIpV4s": [
                            "xxx.xxx.xxx.xxx/n",
                            "xxx.xxx.xxx.xxx/n"
                        ],
                        "subnetIpV6s": [
                            "xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx/n",
                            "xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx/n"
                        ]
                    }
                ],
                "outcome": {
                    "level": $level
                },
                "tlp": "amber",
                "eventAnalysisType": 5,
                "eventType": 29
            }
        ]
    }
}
MYSAMPLE

print $instancefile $str;

	# Closes file handler
	close $instancefile;

$instance++;

}

return "$instance CaRE D1 json sample instances have been generated [OPSSIES Test Toolkit]."; 

# End of sub CaRED1SampleGenerate
}

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Opssies - A toolkit to prepare test content for Opssies.

=head1 SYNOPSIS

#!/usr/bin/perl
use strict;
use warnings;

use OPSSIES qw (CaRED1SampleGenerate);

# Generates 180 json sample instances in line with the CaRED1 profile.
print CaRED1SampleGenerate(180);

=head1 DESCRIPTION

As a perl module, Opssies can be used to prepare test content that can be pushed to Opssies.   

=head2 EXPORT

None by default.


=head1 SEE ALSO

https://opssies.github.io

=head1 AUTHOR

MSP/DNS/RSS/nv

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2024 by msp/dns/rss/nv

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.38.2 or,
at your option, any later version of Perl 5 you may have available.


=cut
