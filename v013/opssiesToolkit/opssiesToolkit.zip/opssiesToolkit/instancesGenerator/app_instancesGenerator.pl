#!/usr/bin/perl
use strict;
use warnings;

use Opssies qw (CaRED1SampleGenerate);

# Generates 180 json sample instances.
print CaRED1SampleGenerate(180);

